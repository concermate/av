//In this sketch I have loaded an acustic guitar arpeggio and I have used oscilators to alter its speed.
//I have also implemented an ADSR envelope and a little atan distortion to the final signal.
//Material used is from Mick Grierson's Goldsmiths University lectures, Maximilian examples and the Creative Programming for Audiovisual Art Kadenze Course.

#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    //sample taken from https://freesound.org/people/digifishmusic/sounds/48254/
    //my intention initially was to bounce wav files from Logic but for some reason it didn't work even though I chose wave format, and 16 bits mono audio so I had to download a loyalty free internet sample instead.
    sampleRate = 44100;
    bufferSize = 512;
    //envelope parameters are at millis
    myEnvelope.setAttack(20000);
    myEnvelope.setDecay(1000);
    myEnvelope.setSustain(1000);
    myEnvelope.setRelease(100);
    //loads a sample from our data folder in our project
    mySample.load("/Users/patricio/Developer/of_v0.9.8_osx_release/apps/myApps/av4/bin/data/guitar.wav");
    ofSoundStreamSetup(2, 2,this,sampleRate,bufferSize,4);
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(0);
    ofSetColor(255);
    ofFill();
    ofDrawBitmapString("AV portfolio 4 (Sample loading and manipulation, and distortion)", 15, 50);
}

//--------------------------------------------------------------
void ofApp::audioOut(float *output, int bufferSize, int numChannels){
    
    for(int i = 0; i < bufferSize; i++){
        
        
        
        
        
        //I gave a sinewave shape to the envelope input.
        envelope=myEnvelope.adsr(myOsc4.sinewave(5),myEnvelope.trigger);
        
        counter=myOsc3.phasor(1, 1, 9);//phasor will give us a count so we can trigger our envelope.
        
        
        if (counter==1) myEnvelope.trigger=1; //triggers envelope when phaser comes back to one
        
        else myEnvelope.trigger=0;//release the envelope
        
        //here I play a sample and I change the speed of the sample dynamicaly using a pulse wave, and sawn wave as the duty.
        
        playSample =mySample.play(myOsc1.pulse(0.01,(myOsc2.sinewave(0.5)+1)/2));
        
        //I added a little distortion and multiplied the result by the envelope value same as we usually do with amplitude.
        myOutput = myDist.atanDist(playSample,12)*envelope;
        //send to the mix
        mix.stereo(myOutput, outputs, 0.2);
        
        output[i * numChannels] = outputs[0];
        output[i * numChannels + 1 ] = outputs[1];
        
        
    }
}




//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}

