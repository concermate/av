#include "ofApp.h"
//In this sketch I experiment with maxiClock and a Phasor to modulate frequencies and also use an array of notes to play a sequence
//Material used is from Mick Grierson's Goldsmiths University lectures, Maximilian examples and the Creative Programming for Audiovisual Art Kadenze Course.
//--------------------------------------------------------------
void ofApp::setup(){
    bufferSize = 512;
    sampleRate = 44100;
    ofSoundStreamSetup(2, 2,this,sampleRate,bufferSize,4);
    clock.setTempo(270);
    clock.setTicksPerBeat(4);
    
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
    ofBackground(0);
    ofSetColor(255);
    ofFill();
    ofDrawBitmapString("AV portfolio 2 (Working with Time and Sequences)", 15, 50);
}
void ofApp::audioOut(float *output, int bufferSize, int numChannels){
    
    for(int i = 0; i < bufferSize; i++){
    
         clock.ticker();
        if (clock.tick) { //frequency
            freq+=50;
            if(freq>800){
                //once the frequency goes over 800hz it picks a new starting point between 50 and 800 hz
                freq=ofRandom(50, 200);
            }
        }
        
        currentCount=phaser.phasor(abs(myOsc2.sawn(0.1)), 1, 17);//phasor use abs to keep values possitive.
        
        //different wave outputs by uncommenting
        
        //cout<<currentCount;
        //currentCount=phaser.phasor(0.1, 1, 17);
            //using FM synth anc clock to shift frequencies
        //wave=myOsc1.sawn(freq+myOsc1.sinewave(100)*20);
        
        //Fm modulation by the use of the phaser
        wave = myOsc1.sinewave(currentCount*50);
        
        //using array of notes as a fundamental, a sawn of 200hz as a carrier and an index of 2500 for sidebands
        //wave=myOsc1.sinewave(myArray[currentCount]+(myOsc3.sawn(200)*2500));
        mix.stereo(wave, outputs, 0.2);
        output[i * numChannels] = outputs[0];
        output[i * numChannels + 1 ] = outputs[1];
        
        
    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
