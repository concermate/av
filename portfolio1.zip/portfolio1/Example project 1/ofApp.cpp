#include "ofApp.h"
//This sketch explores FM synths and additive synthesis using different wave types as well as implementing some counters.
//On default with the commented "waves" until the very last one before the output it plays the fundamental with 10 second 2 set of harmonics and then 2 10 seconds sets of enharmonics.
//Material used is from Mick Grierson's Goldsmiths University lectures, Maximilian examples and the Creative Programming for Audiovisual Art Kadenze Course.
//--------------------------------------------------------------
void ofApp::setup(){
    ofBackground(0);
    text.load("Batang.ttf", 200, true, true, true);
    sampleRate = 44100;
    bufferSize = 512;
    clock.setTempo(60);
    clock.setTicksPerBeat(1);
    ofSoundStreamSetup(2, 2,this,sampleRate,bufferSize,4);
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetColor(255);
    ofFill();
    ofDrawBitmapString("AV portfolio 1 (FM, Additive Synthesis, Counters, enharmonic, harmonic series)", 2, 50);
}

//--------------------------------------------------------------
void ofApp::audioOut(float *output, int bufferSize, int numChannels){
    
    for(int i = 0; i < bufferSize; i++){
        //This clock will trigger 2 counters that will help to create a sequence of 2 10 seconds play of an harmonicaly related increasing harmonics and 2 10 secones enharmonic increase of harmonics.
        clock.ticker();
        if (clock.tick) {
            counter+=1;
            if(counter%10==0){
                counter2+=1;
                if(counter2>3){
                    counter2 = 0;
                }
            }
        }
        //in order for the modulation to be harmonic it needs to be mathematicly related similar as how the sawtooth wave is conformed e.g. fundamental*1,fundamental*2,fundamental + 3, etc.
        if(counter2==2||counter2==3){
            harmonics = 210;
        }else{
            harmonics = 220;
        }
            //osc1 is being modulated by osc2, by going past newquist rate we get an interesting rythmic pattern
            //saw contains all integer harmonics times 2 times 3 times 4
            //with additive we're multiplying wave outputs
        //wave=myOsc1.saw(150)* myOsc2.sinewave(40)*myOsc3.sinewave(3);
        
            //experimenting with a pulse wave by using a sinewave as the duty
       // wave=myOsc1.pulse(100,(myOsc2.sinewave(0.6)*0.5)+0.5)*myOsc3.sinewave(2);
            //FM synthesis where we take two waveforms and multiply them in terms of frequency. We drive the freq of one waveform with another waveform
            //the modulation index changes the amount of sidebands in either side of the fundamental
         //wave=myOsc1.sinewave(440+myOsc2.sinewave(150+myOsc3.sinewave(3))*3000);
        
        //when working with a pulse way we need two arguments (freq and duty) if we want to modulate the duty we need to make sure the value doesn't go below 0 so there isn't a gap.
        //wave=myOsc1.pulse(200,(myOsc2.sinewave(1)+1)/2);
        
        wave= myOsc1.sinewave(110+(myOsc2.sinewave(harmonics)*myOsc3.phasor(0.1,0,1000)));
        mix.stereo(wave, outputs, 0.2);
        
        output[i * numChannels] = outputs[0];
        output[i * numChannels + 1 ] = outputs[1];
        
        
    }
}




//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}

