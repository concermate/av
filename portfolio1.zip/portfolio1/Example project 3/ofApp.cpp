#include "ofApp.h"
//In this sketch I have explored filters and implemented some subtractive synthesis
//Material used is from Mick Grierson's Goldsmiths University lectures, Maximilian examples and the Creative Programming for Audiovisual Art Kadenze Course.
//--------------------------------------------------------------
void ofApp::setup(){
    bufferSize = 9000;
    sampleRate = 44100;
    ofSoundStreamSetup(2, 2,this,sampleRate,bufferSize,4);
    clock.setTempo(270);
    clock.setTicksPerBeat(2);
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    
    ofBackground(0);
    ofSetColor(255);
    ofFill();
    ofDrawBitmapString("AV portfolio 3 (Working with Filters and Subtractive Synthesis)", 15, 50);
    
}
void ofApp::audioOut(float *output, int bufferSize, int numChannels){
    
    for(int i = 0; i < bufferSize; i++){
        
        
        
        currentCount=phaser.phasor(abs(myOsc2.sawn(0.1)), 1, 17);//phasor can take three arguments; frequency, start value and end value.
            //low pass applied to the main output signal. Second parameter filters signal and has values between 0-1:
            //(to try please comment out the mix stereo before outputs)
        
//        wave=myFilter.lopass(myOsc1.sinewave(myArray[currentCount]+(myOsc3.sawn(200)*2500)),0.005);
//        mix.stereo(wave, outputs, 0.5);
        
        
            //add a low pass filter to be used for portamento or slide which is slowing down how long it takes to transition from one pitch to the other:
            //(to try please comment out the mix stereo before outputs)
//        wave=myOsc1.sawn(myFilter.lopass((myArray[currentCount]+(myOsc3.sawn(200)*2500)),0.001));
//        mix.stereo(wave, outputs, 0.5);
        

        //here we can change the mix input for 'wave2' which has a low pass filter or wave which I have subtracted wave2 to create a HIGH PASS filter:
        //float wave2;
        //wave2=myFilter2.lopass(wave,0.8);
        //wave = wave-wave2;
        //mix.stereo(wave2, outputs, 0.2);
        
        //subtractive Synthesis
        
        LFO1Out = LFO1.sawn(0.5)*5;
        LFO2Out =LFO2.sawn(0.3)*100;
        oscOut = myOsc1.sinewave(myArray[currentCount]+LFO2Out);
        
            //lores filter takes as arguments input, cutoff frequency (in hertz) and resonance
        
        filteredOut = myFilter.lores(oscOut,1000+LFO1Out,2+LFO1Out*3);
        mix.stereo(filteredOut, outputs, 0.5);
        
        
        output[i * numChannels] = outputs[0];
        output[i * numChannels + 1 ] = outputs[1];
        

    }
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}

