#pragma once

#include "ofMain.h"
#include "maximilian.h"

class ofApp : public ofBaseApp{
    
public:
    void setup();
    void update();
    void draw();
    
    void keyPressed(int key);
    void keyReleased(int key);
    void mouseMoved(int x, int y );
    void mouseDragged(int x, int y, int button);
    void mousePressed(int x, int y, int button);
    void mouseReleased(int x, int y, int button);
    void mouseEntered(int x, int y);
    void mouseExited(int x, int y);
    void windowResized(int w, int h);
    void dragEvent(ofDragInfo dragInfo);
    void gotMessage(ofMessage msg);
    
    //audio stuff
    void audioOut(float *output, int bufferSize, int numChannels);
    double outputs[2];
    double wave;
    int bufferSize, sampleRate, currentCount;
    float freq = 400;
    maxiClock clock;
    maxiOsc myOsc1, myOsc2, myOsc3, myOsc4, phaser, LFO1,LFO2;
    maxiMix mix;
    int myArray[17]={100,300,200,500,900,400,800,200,1000,600,700,800,300,900,1100,1200,100};
    maxiFilter myFilter, myFilter2;
    //subtractive synthesis variables
    double filteredOut, oscOut, amp,LFO1Out,LFO2Out;
    

};

